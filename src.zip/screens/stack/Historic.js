import { useContext } from "react"
import { StyleSheet, View, ScrollView } from "react-native"
import AuthenticatedContext from '../../context/AuthenticatedContext'
import Background from "../../components/Background"
import CustomHeader from "../../components/headers/CustomHeader"
import Dropdown from "../../components/historic/Dropdown"
import GradeList from "../../components/historic/GradeList"

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    contentContainer: {
        flex: 8,
        padding: 10
    },
    dropdown: {
        marginBottom: 10
    },
    dropdownContent: {
        padding: 5, 
        paddingTop: 10
    },
    gradeListItem: {
        marginTop: 10,
    }
})

export default ({ navigation }) => {

    const { state  } = useContext(AuthenticatedContext)

    const dropdowns = [];
    for (let name in state.historic) {
        if(["OUTROS"].includes(name)) continue 
        const data = state.historic[name]
        dropdowns.push(
            <Dropdown key={dropdowns.length} style={styles.dropdown} contentStyle={styles.dropdownContent} title={name.replace(/_/g, ' ')}>
                <GradeList itemStyle={styles.gradeListItem} data={data}/>
            </Dropdown>
        )
    }

    return (
        <Background style={{flex: 1}}>
            <CustomHeader
                leftButton="chevron-back-outline"
                onLeftButtonClick={() => navigation.goBack()}
                title="SEU HISTORICO" />

            <View style={styles.container}>
                <ScrollView 
                style={styles.contentContainer}>
                    {dropdowns}
                </ScrollView>

            </View>
        </Background>

    )
}
