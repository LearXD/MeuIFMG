import { ActivityIndicator, Modal, StyleSheet, View, Text, Dimensions } from "react-native"
import Colors from "../utils/Colors"

const screenHeight = Dimensions.get('screen').height
const screenWidth = Dimensions.get('screen').width

const styles = StyleSheet.create({
    container: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        height: screenHeight,
        width: screenWidth,
        padding: 5,
        backgroundColor: '#fdfffd',
        opacity: 1
    },
    text: {
        fontSize: 30,
        marginBottom:30,
        flexWrap: 'wrap',
        textAlign: 'center'
    }
})

export default ({message, style}) => {
    return (
        <View style={[styles.container, style]}>
            <Text style={styles.text}>{message}</Text>
            <ActivityIndicator size={45} color={Colors.primary}/>
        </View>
    )
}