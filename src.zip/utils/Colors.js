export default {
    primary: '#309a43'
}